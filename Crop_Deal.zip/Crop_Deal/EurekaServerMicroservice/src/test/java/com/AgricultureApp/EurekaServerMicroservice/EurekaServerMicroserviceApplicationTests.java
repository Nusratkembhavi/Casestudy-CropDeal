package com.AgricultureApp.EurekaServerMicroservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EurekaServerMicroserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
