export class Dealer {
    id: string ;
    dealer_name: string;
    dealer_email: string;
    dealer_contactNo: string;
}
