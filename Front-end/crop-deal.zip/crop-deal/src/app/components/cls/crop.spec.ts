import { Crop } from './crop';

describe('Crop', () => {
  it('should create an instance', () => {
    expect(new Crop()).toBeTruthy();
  });
});
