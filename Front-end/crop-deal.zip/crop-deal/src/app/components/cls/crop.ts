export class Crop {
    id: string ;
    crop_name: string;
    crop_type:string; 
    crop_quantity:string;
    location:string;
    uploaded_by:string;
    price: string;
    
}
