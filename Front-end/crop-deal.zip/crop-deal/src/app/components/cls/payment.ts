export class Payment {
    amount: number;
    name : string;
    cardnumber: number;
    exp: Date;
    status: string;
    cVV: number;
    txnId: string;
}
