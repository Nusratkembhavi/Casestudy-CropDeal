import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-adout-us',
  templateUrl: './adout-us.component.html',
  styleUrls: ['./adout-us.component.css']
})
export class AdoutUsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
